# Práctica 1 #

## Compilación ##

./make

## Eliminar archivos derivados de la compilación ##

./make clean

## Obtener resultados de los algoritmos ##

./make tiempos

./bin/"nombre del ejecutable" "seed" "nombre del fichero de datos con su ruta"

Ej: ./bin/Greedy 0 ./data/MDG-a_2_n500_m50.txt

## Más información ##

Para obtener más información sobre la organización del proyecto, se puede ver la sección Desarrollo de la Práctica de la memoria, ó ver el código de los archivos que contiene comentarios.
